<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

$con = mysqli_connect('localhost','root','','web');
date_default_timezone_set("Europe/Athens");
$current = date("Y-m-d");

if (!empty($_FILES['jsonFile']['name'])) {
  $file = $_FILES['jsonFile']['tmp_name'];
  $data = file_get_contents($file);

    $array = json_decode($data, true);

    foreach ($array as $value) {
      if (!isset($value['current_popularity'])) {
        $value['current_popularity']="null";
      }
      if (!isset($value['time_wait'])) {
        $value['time_wait']=null;
      }
      if (!isset($value['time_spent'])) {
        $value['time_spent']=null;
      }
      if (!isset($value['rating'])) {
        $value['rating']=null;
      }
      if (!isset($value['rating_n'])) {
        $value['rating_n']=null;
      }
      $s = "insert into markers(id,name,address,types,coordinates,rating,rating_n,current_popularity,populartimes,time_wait,time_spent,date_modified) values (
        '".$value['id']."',
        '".$value['name']."',
        '".$value['address']."',
        '".json_encode($value['types'])."',
        '".json_encode($value['coordinates'])."',
        '".$value['rating']."',
        '".$value['rating_n']."',
        '".$value['current_popularity']."',
        '".json_encode($value['populartimes'])."',
        '".json_encode($value['time_wait'])."',
        '".json_encode($value['time_spent'])."',
        '".$current."'
        ) on duplicate key update
        name = '".$value['name']."',
        address = '".$value['address']."',
        types = '".json_encode($value['types'])."',
        coordinates = '".json_encode($value['coordinates'])."',
        rating = '".$value['rating']."',
        rating_n = '".$value['rating_n']."',
        current_popularity = '".$value['current_popularity']."',
        populartimes = '".json_encode($value['populartimes'])."',
        time_wait = '".json_encode($value['time_wait'])."',
        time_spent = '".json_encode($value['time_spent'])."',
        date_modified = '".$current."'";
      mysqli_query($con, $s);

      $types = $value['types'];
      foreach ($types as $type) {
        $s2 = "insert into types (type) values ('".$type."') on duplicate key update type = '".$type."'";
        $result2 = mysqli_query($con, $s2);
      }
    }
    echo "<script> alert('File imported successully!'); window.location = ('./adminhome.php'); </script>";
  }
  else {
    echo "<script> alert('No file selected!'); window.location = ('./adminhome.php'); </script>";
  }

 ?>
