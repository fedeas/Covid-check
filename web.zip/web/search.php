<?php
session_start();
$con = mysqli_connect('localhost','root','','web');
$types = $_POST['types'];
$s = "select * from markers where types like '%".$types."%'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
$data = array();
date_default_timezone_set("Europe/Athens");
$current = date("Y-m-d H:i:s");

if($num > 0) {
  while ($row = $result->fetch_assoc()) {
    $i = 0;
    $estimation = 0;
    $dat = new stdClass();
    $dat->id = $row['id'];
    $dat->name = $row['name'];
    $dat->coordinates = json_decode($row['coordinates']);
    $dat->populartimes = json_decode($row['populartimes']);
    $s2 = "select visits.estimation from markers right join visits on markers.id=visits.marker_id where markers.id='".$row['id']."' and date between date_add('$current', INTERVAL -2 hour) and '$current'";
    $result2 = mysqli_query($con, $s2);
    while ($row2 = $result2->fetch_assoc()) {
      if (isset($row2['estimation'])){
        $i++;
        $estimation += $row2['estimation'];
      }
    }
    if ($i>0)
      $estimation = round($estimation/$i);
    else
      $estimation = "-";
    $dat->estimation = $estimation;
    array_push($data,$dat);
  }
}
echo json_encode($data);
 ?>
