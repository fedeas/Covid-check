<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}
if (isset($_POST['login'])) {
  $con = mysqli_connect('localhost','root','','web');
  if (!$con) {
    die("<script>alert('Connection failed')</script>");
  }

  $username = $_SESSION['username'];
  $newusername = $_POST['newusername'];
  $currentpsw = $_POST['currentpsw'];
  $newpsw = $_POST['newpsw'];
  $cnewpsw = $_POST['cnewpsw'];
  $con = mysqli_connect('localhost','root','','web');

  $s = "select * from user where username = '$username' and password = '$currentpsw'";
  $result = mysqli_query($con, $s);
  $num = mysqli_num_rows($result);

  if ($num > 0){
    if ($newpsw==null){
      $s2 = "select * from user where username = '$newusername' and username != '$username'";
      $result2 = mysqli_query($con, $s2);
      $num2 = mysqli_num_rows($result2);
      if ($num2 > 0)
        echo "<script> alert('Username unavailable, please enter another one'); </script>";
      else{
        $reg = "update user set username = '$newusername' where username = '$username'";
        mysqli_query($con, $reg);
        $_SESSION['username'] = $newusername;
        echo "<script>alert('Username updated!')</script>";
      }
    }
    else if ($newusername!=$username) {
      $s2 = "select * from user where username = '$newusername'";
      $result2 = mysqli_query($con, $s2);
      $num2 = mysqli_num_rows($result2);
      if ($num > 0)
        echo "<script> alert('Username unavailable, please enter another one'); </script>";
      else if ($newpsw != $cnewpsw)
        echo "<script>alert('Password not matched')</script>";
      else {
        $reg = "update user set username = '$newusername', password = '$newpsw' where username = '$username'";
        mysqli_query($con, $reg);
        $_SESSION['username'] = $newusername;
        echo "<script> alert('Username and password updated!'); </script>";
        echo "success";
      }
    }
    else if ($newpsw != $cnewpsw)
        echo "<script> alert('Password not matched'); </script>";
    else {
      $reg = "update user set password = '$newpsw' where username = '$username'";
      mysqli_query($con, $reg);
      echo "<script> alert('Password updated!'); </script>";
      echo "success";
    }
  }
  else
    echo "<script> alert('Wrong current password!'); </script>";
}
 ?>
