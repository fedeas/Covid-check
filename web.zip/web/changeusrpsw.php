<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

 ?>

 <html style="overflow: auto;">
 <head>
   <title>My Profile </title>
   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
 </head>

<body style="overflow: auto;">

  <style>
  .navbar {
    width: 100%;
    background: linear-gradient(to left, #fff, #79f5ff);
    overflow: auto;
    position: fixed;
    margin: 0px;
    z-index: 10000;
  }

  .navbar a {
    float: left;
    padding: 12px;
    color: black;
    text-decoration: none;
    font-size: 20px;
    width: 25%;
    text-align: center;
  }

  .navbar a:hover {
    background-color: #fff;
  }

  .navbar a.active {
    background-color: #79f5ff;
  }

  </style>

  <nav class="navbar">
    <a href="home.php"><i class="fa fa-fw fa-home"></i> Home</a>
    <a href="profile.php"><i class="fa fa-user"></i> My Profile</a>
    <a href="logout.php"><i class="fas fa-door-open"></i> Logout</a>
  </nav>
  <br><br><br>

  <div id="message"> </div>
  <div class="form-box" style="width: 340px;">
    <form id="ChangePassword" class="input-group" style="top: 10px; left: 17px; width:300px;">
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;<i class="fa fa-user fa-align-center" style="font-size: 100px;"></i>
        <input type="text" class="input-field" id="newusername" value=<?php echo $_SESSION['username']; ?> placeholder="New Username" required>
        <input type="password" class="input-field" id="currentpsw" placeholder="Current Password" required>
        <input type="password" class="input-field" id="newpsw" pattern="(?=.*[#$*&@])(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain a minimum of 8 characters and at least one of the following: a number, an uppercase and a lowercase letter and a symbol" placeholder="New Password">
        <input type="password" class="input-field" id="cnewpsw" placeholder="Confirm New Password">
        <input type="submit" class="submit-btn" id="submit" value="Submit" style="width: 120px;">
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script>
    $("#ChangePassword").on('submit', function(event){
      event.preventDefault();
      var newusername = $("#newusername").val();
      var currentpsw = $("#currentpsw").val();
      var newpsw = $("#newpsw").val();
      var cnewpsw = $("#cnewpsw").val();

      $.ajax({
        url: './newusrpsw.php',
        type: 'POST',
        data:{
          login: 1,
          newusername: newusername,
          currentpsw: currentpsw,
          newpsw: newpsw,
          cnewpsw: cnewpsw
        },
        success: function(data) {
            console.log(data);

            if (data.includes("updated")) {
              $('#message').html(data);
              window.location = "./profile.php";
            } else {
                $('#message').html(data);
            }

        },
        error: function() {
            $("#message").html("Wrong username/password, please try again");
        }
      });
    });
  </script>
</body>
