<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}
if (isset($_POST['login'])) {
  $con = mysqli_connect('localhost','root','','web');
  if (!$con) {
    die("<script>alert('Connection failed')</script>");
  }

  $markerid = $_POST['markerid'];
  $est = $_POST['est'];
  $username = $_SESSION['username'];
  $con = mysqli_connect('localhost','root','','web');

  if ($est!=null)
    $reg = "insert into visits(user,marker_id,estimation) values('$username', '$markerid', '$est')";
  else
    $reg = "insert into visits(user,marker_id) values('$username', '$markerid')";

  mysqli_query($con, $reg);
  echo "<script>alert('Visitation submitted!')</script>";
}
 ?>
