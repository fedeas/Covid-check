<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

$username = $_SESSION['username'];
$date = $_POST['date'];
$con = mysqli_connect('localhost','root','','web');
$s = "insert into positive_case (user, date_of_case) values ('$username', '$date')";
$result = mysqli_query($con, $s);
echo "<script>alert('Case submitted. Feel better soon!')</script>";

 ?>
