<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

 ?>

 <html style="overflow: auto;">
 <head>
   <title>My Profile </title>
   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
 </head>

<body style="overflow: auto;">

<style>
.navbar {
  width: 100%;
  background: linear-gradient(to left, #fff, #79f5ff);
  overflow: auto;
  position: fixed;
  margin: 0px;
  z-index: 10000;
}

.navbar a {
  float: left;
  padding: 12px;
  color: black;
  text-decoration: none;
  font-size: 20px;
  width: 33.3%;
  text-align: center;
}

.navbar a:hover {
  background-color: #fff;
}

.navbar a.active {
  background-color: #79f5ff;
}

.popup .overlay{
  position: fixed;
  top: 0px;
  left: 0px;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.7);
  z-index: 1;
  display: none;
}

.popup .content{
  position: absolute;
  top: 30%;
  left: 50%;
  transform: translate(-50%, -50%) scale(0);
  background: linear-gradient(to top, #fff, #79f5ff);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  transition: 0.2s;
  width: 450px;
  height: 300px;
  z-index: 2;
  text-align: center;
  padding: 20px;
  box-sizing: border-box;
  border-radius: 25px;
  margin: 6% auto;
}

.popup .content:hover {
   box-shadow: 0 5px 15px rgba(0, 0, 0, 0.8);
   transition: 0.5s;
}

.popup .close-btn{
  cursor: pointer;
  position: absolute;
  right: 20px;
  top: 1px;
  width: 10px;
  height: 10px;
  color: #FF4933;
  font-size: 30px;
  font-weight: 600;
  line-height: 30px;
  text-align: center;
  border-radius: 50%;
}

.popup.active .overlay{
  display: block;
}

.popup.active .content{
  transition: all 300ms ease-in-out;
  transform: translate(-50%, -50%) scale(1);
}

.date{
  padding: 10px 0;
  margin: 5px 0;
  border-left: 0;
  border-right: 0;
  border-top: 0;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}

</style>

  <nav class="navbar">
    <a href="home.php"><i class="fa fa-fw fa-home"></i> Home</a>
    <a href="changeusrpsw.php"><i class="fas fa-edit"></i> Change Username/Password</a>
    <a href="logout.php"><i class="fas fa-door-open"></i> Logout</a>
  </nav>
  <br><br><br><br>
  <div id="message"> </div>

  <h1 style="text-align: center;">Current covid status: <?php
    $con = mysqli_connect('localhost','root','','web');
    date_default_timezone_set("Europe/Athens");
    $current = date("Y-m-d H:i:s");
    $username = $_SESSION['username'];
    $s = "select * from positive_case where user='$username' and date_of_case between date_add('$current', INTERVAL -14 day) and '$current'";
    $result = mysqli_query($con, $s);
    $num = mysqli_num_rows($result);
    if ($num>0) {
      echo "<p style='color:#33FF3C;'>Positive <i class='fa fa-check'></i> <button type='submit' class='submit-btn' style='width: 180px; display: inline-block; font-size: 22px;' disabled> Report Case </button></p>";
    }
    else {
      echo "<p style='color:#FF4933;'>Negative <i class='fa fa-times-circle'></i> <button type='submit' class='submit-btn' style='width: 180px; display: inline-block; font-size: 22px;' onclick='togglePopup()'> Report Case </button></p>";
    }
   ?>
 </h1>
 <div class="popup" id="popup">
   <div class="overlay"></div>
     <div class="content">
       <div class="close-btn" onclick="togglePopup()">&times;</div>
         <h3> Enter case date </h3>
         <br><br><br>
         <input type="date" class="date" id="date" max="<?php echo date("Y-m-d"); ?>">
         <br><br>
         <button type='submit' class='submit-btn' id='submit' style='width: 180px; font-size: 20px;'> Submit </button>
     </div>
 </div>

<div class="form-box" style="width: 1000px; height: 420px; margin: 50px auto; resize: both; overflow: auto;">
  <h3><p class="text-center">My Visits</p></h3>
  <table class="table table-hover" style="resize: auto;">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Date</th>
      <th scope="col">Possible Contacts with Positive Cases</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $username = $_SESSION['username'];
    $con = mysqli_connect('localhost','root','','web');
    $s = "select visits.date, markers.name, markers.id from visits inner join markers on markers.id=visits.marker_id where user='$username' order by date desc";
    $result = mysqli_query($con, $s);
    $i = 1;
    $username = $_SESSION['username'];
    while ($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td>".$i."</td>";
      echo "<td>".$row['name']."</td>";
      echo "<td>".$row['date']."</td>";
      date_default_timezone_set("Europe/Athens");
      $current = strtotime(date("Y-m-d H:i:s"));
      $diff = ($current-strtotime($row['date']))/60/60/24;
      $num = 0;
      if ($diff<=7){
        $s1 = "select visits.user, visits.marker_id, visits.date from positive_case inner join visits on positive_case.user=visits.user WHERE date_add(date_of_case, INTERVAL -7 day)<visits.date and visits.marker_id='".$row['id']."' and positive_case.user!='$username'";
        $result1 = mysqli_query($con, $s1);
        while ($row1 = $result1->fetch_assoc()) {
          $s2 = "select * from visits where user='$username' and marker_id='".$row['id']."' and date between date_add('".$row1['date']."', INTERVAL -2 hour) and date_add('".$row1['date']."', INTERVAL +2 hour)";
          $result2 = mysqli_query($con, $s2);
          if ($result2->fetch_assoc()){
            $num++;
          }
        }
        echo "<td>".$num."</td>";
      }
      else
        echo "<td>-</td>";
      echo "</tr>";
      $i++;
    }

     ?>
  </tbody>
</table>
</div>

<div class="form-box" style="width: 1000px; height: 420px; margin: 50px auto; resize: both; overflow-y: auto;">
  <h3><p class="text-center">My Positive Cases</p></h3>
  <table class="table table-hover">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Submission Date</th>
      <th scope="col">Case Date</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $s3 = "select * from positive_case where user='$username' order by date_of_case desc";
    $result3 = mysqli_query($con, $s3);
    $j = 1;
    while ($row2 = $result3->fetch_assoc()) {
      echo "<tr>";
      echo "<td>".$j."</td>";
      echo "<td>".$row2['date_of_submission']."</td>";
      echo "<td>".$row2['date_of_case']."</td>";
      echo "</tr>";
      $j++;
    }
     ?>
  </tbody>
</table>
</div>

<script>

function togglePopup(){
document.getElementById("popup").classList.toggle("active");
}

$(document).ready(function(){
  $("#submit").on('click',function(){
    var date = $("#date").val();
    $.ajax({
      url: './reportcase.php',
      type: 'POST',
      data:{
        date: date
      },
      success: function(data){
        console.log(data);
        if (data.includes("Case submitted")) {
          $('#message').html(data);
          window.location = ('./profile.php');
        }
      }
    });
  });
});

</script>

</body>

</html>
