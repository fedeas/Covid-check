<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

 ?>

 <html style="overflow: auto;">
 <head>
   <title> Contact Us </title>
   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
 </head>
<body style="overflow: auto;">

  <style>
  .navbar {
    width: 100%;
    background: linear-gradient(to left, #fff, #79f5ff);
    overflow: auto;
    position: fixed;
    margin: 0px;
    z-index: 10000;
  }

  .navbar a {
    float: left;
    padding: 12px;
    color: black;
    text-decoration: none;
    font-size: 20px;
    width: 25%;
    text-align: center;
  }

  .navbar a:hover {
    background-color: #fff;
  }

  .navbar a.active {
    background-color: #79f5ff;
  }
  </style>

  <nav class="navbar">
    <a href="home.php"><i class="fa fa-fw fa-home"></i> Home</a>
    <a class="active" href="contact.php"><i class="fa fa-envelope"></i> Contact Us</a>
    <a href="profile.php"><i class="fa fa-user"></i> My Profile</a>
    <a href="logout.php"><i class="fas fa-door-open"></i> Logout</a>
  </nav>
  <br><br><br>

  <div class="form-box">
    <div class="text-center">
      <div class="align-items-center">
        <br><br><br>
        <p>ΑΝΤΩΝΙΟΥ ΠΕΤΡΟΣ ΑΜ: 1063017 <br> <i class="fa fa-envelope"></i> up1063017@upnet.gr</p>
        <p>ΓΕΔΕΩΝ ΦΕΙΔΙΑΣ ΑΜ: 1063023 <br> <i class="fa fa-envelope"></i> up1063023@upnet.gr</p>
        <p>ΚΑΝΕΛΛΟΠΟΥΛΟΣ ΚΩΝΣΤΑΝΤΙΝΟΣ ΑΜ: 1067493 <br> <i class="fa fa-envelope"></i> up1067493@upnet.gr</p>
        <p>ΧΡΙΣΤΟΔΟΥΛΙΔΗΣ ΜΙΧΑΛΗΣ ΑΜ: 1063020 <br> <i class="fa fa-envelope"></i> up1063020@upnet.gr</p>
      </div>
    </div>
  </div>

</body>

</html>
