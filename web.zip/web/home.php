<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}
 ?>

<html style="overflow: auto;">

<head>
    <title> Home Page </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.googleapis.com/css?family=Arvo' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

    <style>
        #map {
            height: 480px;
            width: auto;
            margin-top: 60px;
        }

        .navbar {
          width: 100%;
          background: linear-gradient(to left, #fff, #79f5ff);
          overflow: auto;
          position: fixed;
          margin: 0px;
          z-index: 10000;
        }

        .navbar a {
          float: left;
          padding: 12px;
          color: black;
          text-decoration: none;
          font-size: 20px;
          width: 25%;
          text-align: center;
        }

        .navbar a:hover {
          background-color: #fff;
        }

        .navbar a.active {
          background-color: #79f5ff;
        }
    </style>
</head>

<body style="overflow: auto;">

  <nav class="navbar">
    <a class="active" href="home.php"><i class="fa fa-fw fa-home"></i> Home</a>
    <a href="contact.php"><i class="fa fa-envelope"></i> Contact Us</a>
    <a href="profile.php"><i class="fa fa-user"></i> My Profile</a>
    <a href="logout.php"><i class="fas fa-door-open"></i> Logout</a>
  </nav>
  <br><br><br><br>

  <h1 style="text-align: center;">Welcome <?php echo $_SESSION['username']; ?>! </h1>

  <div class="form-box" style="width: 1000px; height: 560px; margin: 0px auto;">
    <input type="text" class="input-field" id="search" placeholder="Search" style="margin: 10; width: 850px; padding: 2px 0; white-space: nowrap;">
    <button type="submit" class="submit-btn" id="searchbtn" style="width: 100px; display: inline-block;"><i class="fas fa-search"></i></button>
    <div id="map" style="margin: 5px;"></div>
  </div>

    <script>
        var mymap = L.map("map");
        let tiles = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png");
        tiles.addTo(mymap);

        getLocation();

        function getLocation() {
            mymap.locate({setView: true, enableHighAccuracy: true})
            .on('locationfound', function(e) {
                let marker = L.marker(e.latlng, {draggable: "true", iconSize: [25,41]});
                //mymap.setView(e.latlng, 13);
                marker.addTo(mymap);
                marker.bindPopup("<b>My Location</b>");
            })
        }

        var markersLayer = new L.LayerGroup();
        mymap.addLayer(markersLayer);

        $(document).ready(function(){
          $("#searchbtn").on('click',function(){
            var types = $("#search").val();
            $.ajax({
              url: './search.php',
              type: 'POST',
              data:{
                types: types
              },
              success: function(data){
                var dat = JSON.parse(data);
                result(dat);
              }
            });
          });
        });

          $('#search').keypress(function (event) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
              var types = $("#search").val();
              $.ajax({
                url: './search.php',
                type: 'POST',
                data:{
                  types: types
                },
                success: function(data){
                  var dat = JSON.parse(data);
                  result(dat);
                }
              });
            }
          });

        function result(data){
            mymap.locate({setView: true, enableHighAccuracy: true})
            .on('locationfound', function(e) {
              var today = new Date();
              var day = today.getDay();
              var time = today.getHours();

              if (day==0) {
                day = 6;
              }
              else {
                day--;
              }

              var redIcon = new L.Icon({
                 iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
                 iconSize: [25, 41]
               });

               var greenIcon = new L.Icon({
                  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
                  iconSize: [25, 41]
                });

                var orangeIcon = new L.Icon({
                   iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-orange.png',
                   iconSize: [25, 41]
                 });

              for(i in data) {
                var markerid = data[i].id, name = data[i].name, coordinates = data[i].coordinates, pr_estimation = data[i].estimation, visits, total=0;
                if(time!=23)
                  visits = data[i].populartimes[day].data[time]+data[i].populartimes[day].data[time+1];
                else if(day!=6)
                  visits = data[i].populartimes[day].data[time]+data[i].populartimes[day+1].data[0];
                else
                  visits = data[i].populartimes[day].data[time]+data[i].populartimes[0].data[0];
                for (var j = 0; j < 24; j++) {
                  total += data[i].populartimes[day].data[j];
                }
                var per = (visits/total)*100, color=greenIcon;
                if(total!=0){
                  if(per<=32)
                    color=greenIcon;
                  else if(per<=65)
                    color=orangeIcon;
                  else
                    color=redIcon;
                }

                marker = new L.Marker(new L.latLng(coordinates), {icon: color, initial:false, marker: false});
                var mylocation = e.latlng;
                //var mylocation = {lat:38.23566259999999,lng:21.7460654};

                var R = 6371e3;
                var f1 = mylocation.lat * Math.PI/180;
                var f2 = coordinates.lat * Math.PI/180;
                var df = (coordinates.lat-mylocation.lat) * Math.PI/180;
                var dl = (coordinates.lng-mylocation.lng) * Math.PI/180;

                var a = Math.sin(df/2) * Math.sin(df/2) + Math.cos(f1) * Math.cos(f2) * Math.sin(dl/2) * Math.sin(dl/2);
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

                var d = R * c;
                if (d <= 20) {
                  marker.bindPopup('<div class="text-center"> <b>' + name
                  + '</b> <br> <br> <br> <input type="hidden" id="mark" value="' + markerid + '">'
                  + "Estimated population for next 2 hours: " + visits
                  + "<br> Average population in previous 2 hours: " + pr_estimation
                  + '<br> Estimated population right now (Optional): '
                  + '<input type="text" id="estimation" maxlength="4" size="4"> <br>'
                  + '<button type="submit" class="submit-btn" id="submitbtn" style="width: 100px" onclick="visit()"> Visited </button> </div>');
                  marker.addTo(markersLayer);
                  mymap.setView(coordinates);
                }
                else {
                  marker.bindPopup('<div class="text-center"> <b>' + name
                  + '</b> <br> <br>' + "Estimated population for next 2 hours: " + visits
                  + "<br> Average population in previous 2 hours: " + pr_estimation);
                  marker.addTo(markersLayer);
                  mymap.setView(coordinates);
                }
                total=0;
              }
            })
          }

        function visit(){
          var est = $("#estimation").val();
          var markerid = $("#mark").val();
            $.ajax({
              url: './visit.php',
              type: 'POST',
              data: {
                login: 1,
                markerid: markerid,
                est: est
              },
              success: function(data) {
                alert("Visitation submitted!");
                console.log(data);
                mymap.closePopup();
              }
            });
        }

    </script>
</body>
</html>
