<?php

session_start();
$con = mysqli_connect('localhost','root','','web');
$s = "delete from markers";
mysqli_query($con, $s);

echo "<script>alert('Data deleted successully')</script>";
 ?>
