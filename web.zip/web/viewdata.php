<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

$con = mysqli_connect('localhost','root','','web');
function getStartAndEndDate($week, $year) {
  $dto = new DateTime();
  $dto->setISODate($year, $week);
  $ret['week_start'] = $dto->format('Y-m-d');
  $dto->modify('+6 days');
  $ret['week_end'] = $dto->format('Y-m-d');
  return $ret;
}

if (isset($_POST['dateweek'])){
  $week = date('W', strtotime($_POST['dateweek']));
  $year = date('Y', strtotime($_POST['dateweek']));
  $week_array = getStartAndEndDate($week,$year);
  $start = $week_array['week_start'];
  $end = $week_array['week_end'];
  $data = array();

  for ($i=0; $i < 7; $i++) {
    $s = "select count(*) as visits from visits where date between date_add('$start', INTERVAL ".$i." day) and date_add('$start', INTERVAL ".++$i." day)";
    $result = mysqli_query($con, $s);
    $s2 = "select count(*) as cases from positive_case inner join visits on positive_case.user=visits.user WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day)
    and date between date_add('$start', INTERVAL ".--$i." day) and date_add('$start', INTERVAL ".++$i." day)";
    $result2 = mysqli_query($con, $s2);
    $dat = new stdClass();
    $dat->visits = $result->fetch_assoc();
    $dat->cases = $result2->fetch_assoc();
    array_push($data,$dat);
    $i--;
  }
}
elseif (isset($_POST['datemonth'])){
  $date = $_POST['datemonth'];
  $month = date('m', strtotime($_POST['datemonth']));
  switch ($month) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      $max = 31;
      break;
    case 4:
    case 6:
    case 9:
    case 11:
      $max = 30;
      break;
    case 2:
      if (date('L', strtotime($_POST['datemonth'])))
        $max = 29;
      else
        $max = 28;
      break;
  }
  $data = array();
  for ($i=1; $i < $max+1; $i++) {
    $dat = new stdClass();
    if ($i<10) {
      $s = "select count(*) as visits from visits where date like '".$date."-0".$i."%'";
      $s2 = "select count(*) as cases from positive_case inner join visits on positive_case.user=visits.user WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day)
      and date like '".$date."-0".$i."%'";
      $dat->date = "".$date."-0".$i."";
    }
    else {
      $s = "select count(*) as visits from visits where date like '".$date."-".$i."%'";
      $s2 = "select count(*) as cases from positive_case inner join visits on positive_case.user=visits.user WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day)
      and date like '".$date."-".$i."%'";
      $dat->date = "".$date."-".$i."";
    }
    $result = mysqli_query($con, $s);
    $result2 = mysqli_query($con, $s2);
    $dat->visits = $result->fetch_assoc();
    $dat->cases = $result2->fetch_assoc();
    $dat->days = $max;
    array_push($data,$dat);
  }
}
elseif (isset($_POST['dateday'])) {
  $data = array();
  $date = $_POST['dateday'];
  for ($i=0; $i < 24; $i++) {
    $dat = new stdClass();
    if ($i<10) {
      $s = "select count(*) as visits from visits where date like '".$date." 0".$i."%'";
      $s2 = "select count(*) as cases from positive_case inner join visits on positive_case.user=visits.user WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day)
      and date like '".$date." 0".$i."%'";
      $dat->time = "0".$i.":00";
    }
    else {
      $s = "select count(*) as visits from visits where date like '".$date." ".$i."%'";
      $s2 = "select count(*) as cases from positive_case inner join visits on positive_case.user=visits.user WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day)
      and date like '".$date." ".$i."%'";
      $dat->time = "".$i.":00";
    }
    $result = mysqli_query($con, $s);
    $result2 = mysqli_query($con, $s2);
    $dat->visits = $result->fetch_assoc();
    $dat->cases = $result2->fetch_assoc();
    array_push($data,$dat);
  }
}

echo json_encode($data);

 ?>
