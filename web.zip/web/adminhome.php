<?php

session_start();
if (!isset($_SESSION['loggedin'])) {
  header('location: ./index.html');
  exit();
}

 ?>

<html style="overflow: auto;">

<head>
    <title> Home Page </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.googleapis.com/css?family=Arvo' rel='stylesheet' type='text/css'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
</head>

<body style="overflow: auto;">

  <style>
      .navbar {
        width: 100%;
        background: linear-gradient(to left, #fff, #79f5ff);
        overflow: auto;
        position: fixed;
        margin: 0px;
        z-index: 10000;
      }

      .navbar a {
        float: left;
        padding: 12px;
        color: black;
        text-decoration: none;
        font-size: 20px;
        width: 100%;
        text-align: center;
      }

      .navbar a:hover {
        background-color: #fff;
      }

      .navbar a.active {
        background-color: #79f5ff;
      }

      .popup .overlay{
        position: fixed;
        top: 0px;
        left: 0px;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.7);
        z-index: 1;
        display: none;
      }

      .popup .content{
        position: absolute;
        top: 30%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0);
        background: linear-gradient(to top, #fff, #79f5ff);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        transition: 0.2s;
        width: 450px;
        height: 220px;
        z-index: 2;
        text-align: center;
        padding: 20px;
        box-sizing: border-box;
        border-radius: 25px;
        margin: 6% auto;
      }

      .popup .content:hover {
         box-shadow: 0 5px 15px rgba(0, 0, 0, 0.8);
         transition: 0.5s;
      }

      .popup.active .overlay{
        display: block;
      }

      .popup.active .content{
        transition: all 300ms ease-in-out;
        transform: translate(-50%, -50%) scale(1);
      }

      .date{
        padding: 10px 0;
        margin: 5px 0;
        border-left: 0;
        border-right: 0;
        border-top: 0;
        border-bottom: 1px solid #999;
        outline: none;
        background: transparent;
      }
  </style>

  <nav class="navbar">
    <a href="logout.php"><i class="fas fa-door-open"></i> Logout</a>
  </nav>
  <br><br><br><br>

  <div id="message"> </div>
  <div class="popup" id="popup">
    <div class="overlay"></div>
      <div class="content">
        <h3> Are you sure you want to delete all data? </h3>
        <br><br>
        <button type='submit' class='submit-btn' id='submit' style='width: 100px; font-size: 20px; padding: 5px; display: inline-block;'> Yes </button>
        &emsp;&emsp;&emsp;&emsp;
        <button type='submit' class='submit-btn' style='width: 100px; font-size: 20px; padding: 5px; display: inline-block;' onclick="togglePopup()"> No </button>
      </div>
  </div>

  <h1 style="text-align: center;">Welcome <?php echo $_SESSION['username']; ?>! </h1> <br> <br>
    <form method="post" style="text-align: center; font-size: 22px;" enctype="multipart/form-data" action="./import.php">
      Import JSON file: <input type='file' name="jsonFile"> <br> <br>
      <button type='submit' class='submit-btn' name="buttonImport" style='width: 140px; font-size: 22px; padding: 5px; display: inline-block;'> Import </button>
    </form>
    <button type='submit' class='submit-btn' name="delete" style='width: 200px; font-size: 22px; padding: 5px;' onclick='togglePopup()'> Delete all data </button>
    <br>

  <div class="form-box" style="width: 1000px; height: 300px; margin: 0px auto; overflow: auto;">
    <table class="table table-hover" style="margin:5px 0px;">
    <thead class="thead-dark">
      <tr>
        <th scope="col">#</th>
        <th scope="col">Description</th>
        <th scope="col">Amount</th>
      </tr>
    </thead>
    <tbody>
      <?php
      date_default_timezone_set("Europe/Athens");
      $con = mysqli_connect('localhost','root','','web');
      $s = "select count(*) as total from visits";
      $result = mysqli_query($con, $s);
      $row = $result->fetch_assoc();
      echo "<tr>";
      echo "<td>1</td>";
      echo "<td>Visits</td>";
      echo "<td>".$row['total']."</td>";
      echo "</tr>";

      $s2 = "select count(*) as total from positive_case";
      $result2 = mysqli_query($con, $s2);
      $row2 = $result2->fetch_assoc();
      echo "<tr>";
      echo "<td>2</td>";
      echo "<td>Positive cases</td>";
      echo "<td>".$row2['total']."</td>";
      echo "</tr>";

      $s3 = "select count(*) as total from positive_case inner join visits on positive_case.user=visits.user WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day)";
      $result3 = mysqli_query($con, $s3);
      $row3 = $result3->fetch_assoc();
      echo "<tr>";
      echo "<td>3</td>";
      echo "<td>Visits from positive cases</td>";
      echo "<td>".$row3['total']."</td>";
      echo "</tr>";
      ?>
   </tbody>
 </table>
 </div>
 <br>
 <div class="form-box" style="width: 1000px; height: 300px; margin: 0px auto; overflow: auto;">
   <table class="table table-hover" style="margin:5px 0px;" id="myTable">
   <thead class="thead-dark">
     <tr>
       <th scope="col">Type</th>
       <th scope="col">Amount of visits</th>
     </tr>
   </thead>
   <tbody>
  <?php
    $s4 = "select type from types";
    $result4 = mysqli_query($con, $s4);
    while ($row4 = $result4->fetch_assoc()){
      $s5 = "select count(*) as total from markers inner join visits on markers.id=visits.marker_id where types like '%".$row4['type']."%'";
      $result5 = mysqli_query($con, $s5);
      $row5 = $result5->fetch_assoc();
      echo "<tr>";
      echo "<td>".$row4['type']."</td>";
      echo "<td>".$row5['total']."</td>";
      echo "</tr>";
    }

    ?>
  </tbody>
</table>
</div>

</div>
<br>
<div class="form-box" style="width: 1000px; height: 300px; margin: 0px auto; overflow: auto;">
  <table class="table table-hover" style="margin:5px 0px;" id="myTable2">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Type</th>
      <th scope="col">Amount of cases</th>
    </tr>
  </thead>
  <tbody>
 <?php
   $s4 = "select type from types";
   $result4 = mysqli_query($con, $s4);
   while ($row4 = $result4->fetch_assoc()){
     $s5 = "select count(*) as total from positive_case inner join visits on positive_case.user=visits.user INNER join markers on markers.id=visits.marker_id WHERE visits.date BETWEEN date_add(date_of_case, INTERVAL -7 day) and date_add(date_of_case, INTERVAL 14 day) and types LIKE '%".$row4['type']."%'";
     $result5 = mysqli_query($con, $s5);
     $row5 = $result5->fetch_assoc();
     echo "<tr>";
     echo "<td>".$row4['type']."</td>";
     echo "<td>".$row5['total']."</td>";
     echo "</tr>";
   }
   ?>
 </tbody>
</table>
</div>
<br>
<div class="form-box" id="graph-container" style="width: 1100px; height: 600px; margin: 0px auto; text-align: center;">
  <h2> Visits & Visits form Positive Cases </h3>
  <input type="week" class="date" id="week" max="<?php echo date('Y').'-W'.date('W'); ?>">
  <button type='submit' class='submit-btn' id='viewweek' style='width: 180px; font-size: 20px; display: inline-block;'> View data </button>
  &emsp;&emsp;
  <input type="month" class="date" id="month" max="<?php echo date('Y-m'); ?>">
  <button type='submit' class='submit-btn' id='viewmonth' style='width: 180px; font-size: 20px; display: inline-block;'> View data </button>
  &emsp;&emsp;
  <input type="date" class="date" id="day" max="<?php echo date("Y-m-d"); ?>">
  <button type='submit' class='submit-btn' id='viewday' style='width: 180px; font-size: 20px; display: inline-block;'> View data </button>
  <canvas id="myChart" style="width:900px; max-width:950px; height: 400px; margin:10px;"></canvas>
</div>
<br><br>
<script>

    function togglePopup(){
    document.getElementById("popup").classList.toggle("active");
    }

    $(document).ready(function(){
      $("#submit").on('click',function(){
        $.ajax({
          url: './deletedata.php',
          type: 'POST',
          success: function(data){
            console.log(data);
            if (data.includes("deleted")) {
              $('#message').html(data);
              togglePopup();
              window.location = "./adminhome.php";
            }
          }
        });
      });
    });

    sortTable();
    sortTable2();

    function sortTable() {
      var table, rows, switching, i, x, y, shouldSwitch;
      table = document.getElementById("myTable");
      switching = true;
      while (switching) {
        switching = false;
        rows = table.rows;
        for (i = 1; i < (rows.length - 1); i++) {
          shouldSwitch = false;
          x = rows[i].getElementsByTagName("TD")[1];
          y = rows[i + 1].getElementsByTagName("TD")[1];
          if (Number(x.innerHTML) < Number(y.innerHTML)) {
            shouldSwitch = true;
            break;
          }
        }
        if (shouldSwitch) {
          rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
          switching = true;
        }
      }
    }

    function sortTable2() {
      var table, rows, switching, i, x, y, shouldSwitch;
      table = document.getElementById("myTable2");
      switching = true;
      while (switching) {
        switching = false;
        rows = table.rows;
        for (i = 1; i < (rows.length - 1); i++) {
          shouldSwitch = false;
          x = rows[i].getElementsByTagName("TD")[1];
          y = rows[i + 1].getElementsByTagName("TD")[1];
          if (Number(x.innerHTML) < Number(y.innerHTML)) {
            shouldSwitch = true;
            break;
          }
        }
        if (shouldSwitch) {
          rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
          switching = true;
        }
      }
    }

    $(document).ready(function(){
      $("#viewweek").on('click',function(){
        var dateweek = $("#week").val();
        $.ajax({
          url: './viewdata.php',
          type: 'POST',
          data:{
            dateweek: dateweek
          },
          success: function(data){
            //console.log(data);
            var dat = JSON.parse(data);
            week(dat);
          }
        });
      });

      $("#viewmonth").on('click',function(){
        var datemonth = $("#month").val();
        $.ajax({
          url: './viewdata.php',
          type: 'POST',
          data:{
            datemonth: datemonth
          },
          success: function(data){
            //console.log(data);
            var dat = JSON.parse(data);
            month(dat);
          }
        });
      });

      $("#viewday").on('click',function(){
        var dateday = $("#day").val();
        $.ajax({
          url: './viewdata.php',
          type: 'POST',
          data:{
            dateday: dateday
          },
          success: function(data){
            //console.log(data);
            var dat = JSON.parse(data);
            day(dat);
          }
        });
      });
    });


function week(data){
  $('#myChart').remove();
  $('#graph-container').append('<canvas id="myChart" style="width:900px; max-width:950px; height: 400px; margin:10px;"><canvas>');
  var xValues = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
  var myChart = new Chart("myChart");
  if (myChart !== null)
    myChart.destroy();
  var myChart = new Chart("myChart", {
    type: "bar",
    data: {
      labels: xValues,
      datasets: [{
        data: [data[0].visits.visits,data[1].visits.visits,data[2].visits.visits,data[3].visits.visits,data[4].visits.visits,data[5].visits.visits,data[6].visits.visits],
        backgroundColor: "#33FF3C",
        label: "Number of visits",
      },{
        data: [data[0].cases.cases,data[1].cases.cases,data[2].cases.cases,data[3].cases.cases,data[4].cases.cases,data[5].cases.cases,data[6].cases.cases],
        backgroundColor: "#FF4933",
        label: "Number of visits from positive cases",
      }]
    },
    options: {
      legend: {display: true},
    }
  });
}

function month(data){
  $('#myChart').remove();
  $('#graph-container').append('<canvas id="myChart" style="width:900px; max-width:950px; height: 400px; margin:10px;"><canvas>');
  const xValues = [];
  const visits = [];
  const cases = [];
  var days = data[0].days;
  for (var i = 0; i < days; i++) {
    xValues.push(data[i].date);
    visits.push(data[i].visits.visits);
    cases.push(data[i].cases.cases);
  }

  new Chart("myChart", {
    type: "bar",
    data: {
      labels: xValues,
      datasets: [{
        data: visits,
        backgroundColor: "#33FF3C",
        label: "Number of visits",
      },{
        data: cases,
        backgroundColor: "#FF4933",
        label: "Number of visits from positive cases",
      }]
    },
    options: {
      legend: {display: true},
    }
  });
}

function day(data){
  $('#myChart').remove();
  $('#graph-container').append('<canvas id="myChart" style="width:900px; max-width:950px; height: 400px; margin:10px;"><canvas>');
  const xValues = [];
  const visits = [];
  const cases = [];
  var days = data[0].days;
  for (var i = 0; i < 24; i++) {
    xValues.push(data[i].time);
    visits.push(data[i].visits.visits);
    cases.push(data[i].cases.cases);
  }

  new Chart("myChart", {
    type: "line",
    data: {
      labels: xValues,
      datasets: [{
        data: visits,
        borderColor: "#33FF3C",
        label: "Number of visits",
        fill: false,
      },{
        data: cases,
        borderColor: "#FF4933",
        label: "Number of visits from positive cases",
        fill: false,
      }]
    },
    options: {
      legend: {display: true},
    }
  });
}

</script>
</body>
</html>
