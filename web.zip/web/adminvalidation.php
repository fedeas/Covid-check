<?php
session_start();

if (isset($_SESSION['loggedin'])) {
  header('location: ./home.php');
  exit();
}

if (isset($_POST['login'])) {
  $con = mysqli_connect('localhost','root','','web');
  if (!$con) {
    die("<script>alert('Connection failed')</script>");
  }

  $username = $_POST['username'];
  $password = $_POST['password'];
  $s = "select * from admin where username = '$username' && password = '$password'";
  $result = mysqli_query($con, $s);
  $num = mysqli_num_rows($result);

  if($num > 0) {
    $_SESSION['loggedin'] = '1';
    $_SESSION['username'] = $username;
    echo "success";
  }
  else {
    echo "<script> alert('Wrong username/password, please try again'); </script>";
  }
}

 ?>
