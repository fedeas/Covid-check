<?php
session_start();

$con = mysqli_connect('localhost','root','','web');

if (!$con) {
  die("<script>alert('Connection failed')</script>");
}

$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

$s = "select * from user where email = '$email'";
$s2 = "select * from user where username = '$username'";
$result = mysqli_query($con, $s);
$result2 = mysqli_query($con, $s2);
$num = mysqli_num_rows($result);
$num2 = mysqli_num_rows($result2);

if ($password != $cpassword)
  echo "<script>alert('Password not matched')</script>";
else if($num > 0)
  echo "<script>alert('There is already an account registered with this email, please enter another one')</script>";
else if ($num2 > 0)
  echo "<script>alert('Username unavailable, please enter another one')</script>";
else{
  $reg = "insert into user(username,password,email) values('$username', '$password','$email')";
  mysqli_query($con, $reg);
  echo "<script>alert('User registration completed!')</script>";
}
 ?>
